// Background: keeps the friends list fresh (your Octane friends plus any
// extra watched users), shows the online count on the toolbar badge, sends
// online / joined-a-game alerts, counts your playtime, caches Octomons item
// values, and fetches cross-origin stylesheets for the theme engine.
// Chrome/Brave run this as a service worker; Firefox/Zen load the shared
// scripts first via manifest "background.scripts".
if (typeof importScripts === "function") {
  importScripts("shared/compat.js", "shared/settings.js", "shared/values.js");
}

const S = globalThis.KeroseneSettings;
const V = globalThis.KeroseneValues;
const ALARM = "kerosene-friends";
const AVATAR_TTL = 60 * 60 * 1000;

function ensureAlarm() {
  ext.alarms.get(ALARM, (a) => {
    if (!a) ext.alarms.create(ALARM, { periodInMinutes: 1, delayInMinutes: 1 });
  });
}

function notify(id, title, message) {
  ext.notifications.create(`kerosene-${id}-${Date.now()}`, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
    priority: 0,
  });
}

let polling = null;
function pollFriends() {
  // one poll at a time; the popup and the alarm can both ask
  polling ??= doPoll().finally(() => { polling = null; });
  return polling;
}

async function doPoll() {
  const settings = await S.load();
  const { viewer = null, friendStatus = {}, friendsMeta = {}, avatars = {}, avatarsAt = 0 } =
    await ext.storage.local.get(["viewer", "friendStatus", "friendsMeta", "avatars", "avatarsAt"]);
  const next = {};
  let syncError = null;

  if (settings.syncFriends && viewer?.id) {
    try {
      for (const f of await S.fetchFriends(viewer.id)) next[f.id] = f;
    } catch (err) {
      syncError = String(err.message || err);
      // keep this account's last list until the next good sync
      if (friendsMeta.viewerId === viewer.id) {
        for (const f of Object.values(friendStatus)) if (f.friend) next[f.id] = { ...f, live: false };
      }
    }
  }

  await Promise.all(settings.friends.filter((id) => !next[id]).map(async (id) => {
    try {
      next[id] = await S.fetchUser(id);
    } catch (err) {
      next[id] = { ...(friendStatus[id] || { id, name: `#${id}`, displayName: `#${id}`, status: "offline" }), error: String(err.message || err) };
    }
  }));

  // Real presence for everyone, and for you (playtime). The friends list only
  // knows online/offline; if this fails its online flags stay.
  const ids = Object.keys(next).map(Number);
  const now = Date.now();
  let presence = null;
  const counting = Boolean(viewer?.id && settings.enabled && settings.trackPlaytime);
  const askIds = [...new Set([...ids, ...(counting ? [Number(viewer.id)] : [])])];
  if (askIds.length) {
    try {
      presence = await S.fetchPresence(askIds);
    } catch { /* keep what the friends list said */ }
  }
  const mine = counting ? presence?.[viewer.id] || null : null;
  // the last look was recent (no browser restart or sleep in between)
  const fresh = now - (friendsMeta.checked || 0) <= PLAY_GAP;
  for (const f of Object.values(next)) {
    if (f.error) continue;
    const prev = friendStatus[f.id];
    if (presence?.[f.id]) {
      Object.assign(f, presence[f.id], { live: true, liveAt: now });
      continue;
    }
    // no live look this time: someone still online stays in the game they were
    // in, for a few minutes after the last live look
    if (prev?.status === "ingame" && f.status !== "offline" && prev.liveAt && now - prev.liveAt <= PLAY_GAP) {
      Object.assign(f, { status: "ingame", location: prev.location, placeId: prev.placeId, universeId: prev.universeId, since: prev.since, liveAt: prev.liveAt, live: false });
    }
  }
  const universes = [...new Set([...Object.values(next), mine].filter((f) => f?.status === "ingame" && f.universeId).map((f) => f.universeId))];
  const games = universes.length ? await gameInfo(universes) : {};
  for (const f of Object.values(next)) {
    if (f.status !== "ingame") continue;
    const g = games[f.universeId];
    if (g?.name) f.location = g.name;
    if (g?.placeId) f.placeId = g.placeId;
    // how long they've been in this game (as far as Kerosene has seen)
    const prev = friendStatus[f.id];
    f.since = fresh && prev?.status === "ingame" && prev.universeId === f.universeId && prev.since ? prev.since : now;
  }
  if (mine) {
    await recordPlay(viewer.id, mine, games[mine.universeId], now).catch(() => {});
  } else if (viewer?.id && !counting) {
    await endSession(viewer.id).catch(() => {}); // time while counting is off doesn't count later
  }

  // avatars: refresh hourly, and fetch any we don't have yet
  const stale = Date.now() - avatarsAt > AVATAR_TTL;
  const missing = stale ? ids : ids.filter((id) => !avatars[id]);
  let avatarMap = avatars;
  if (missing.length) {
    avatarMap = { ...avatars, ...(await S.fetchHeadshots(missing)) };
  }

  if (settings.enabled) {
    for (const f of Object.values(next)) {
      const prev = friendStatus[f.id];
      if (!prev || prev.error || f.error) continue; // first sighting: no alert
      const name = f.displayName || f.name;
      // games only from real presence on both looks (no burst after a failed look)
      if (settings.notifyGames && f.live && prev.live && f.status === "ingame" && (prev.status !== "ingame" || prev.universeId !== f.universeId)) {
        notify(f.placeId ? `game-${f.placeId}` : `user-${f.id}`, `${name} is playing`, f.location);
      } else if (settings.notifyOnline && prev.status === "offline" && f.status !== "offline") {
        notify(`user-${f.id}`, `${name} is online`, "Your Octane friend just came online.");
      }
    }
  }

  const checked = Date.now();
  await ext.storage.local.set({
    friendStatus: next,
    friendsMeta: { checked, syncError, synced: Boolean(settings.syncFriends && viewer?.id), viewerId: viewer?.id ?? null },
    avatars: avatarMap,
    ...(stale && missing.length ? { avatarsAt: checked } : {}),
  });

  const online = Object.values(next).filter((f) => f.status !== "offline").length;
  await ext.action.setBadgeBackgroundColor({ color: "#4fa3e0" });
  await ext.action.setBadgeText({ text: settings.enabled && online ? String(online) : "" });
  return next;
}

// ---------- games & playtime ----------
// Game names and root places by universe, cached (presence only says "Playing")
const GAME_TTL = 6 * 60 * 60 * 1000;
async function gameInfo(universeIds) {
  const { gameInfo: cache = {} } = await ext.storage.local.get("gameInfo");
  const now = Date.now();
  const missing = universeIds.filter((u) => !cache[u] || now - cache[u].at > GAME_TTL);
  if (missing.length) {
    try {
      const stats = await S.fetchGameStats(missing);
      for (const u of missing) if (stats[u]) cache[u] = { name: stats[u].name, placeId: stats[u].placeId, at: now };
      const keep = Object.entries(cache).sort((a, b) => b[1].at - a[1].at).slice(0, 300);
      await ext.storage.local.set({ gameInfo: Object.fromEntries(keep) });
      return Object.fromEntries(keep);
    } catch { /* names are cosmetic */ }
  }
  return cache;
}

// Your playtime: playtime[userId] = { games: { [universeId]: { name, placeId,
// total, sessions, last } }, days: { "YYYY-MM-DD": ms }, current }. Time
// between two sightings in the same game counts; a longer gap than PLAY_GAP
// (browser closed, computer asleep) doesn't, and starts a new session.
const PLAY_GAP = 5 * 60 * 1000;
const PLAY_DAYS = 120;
const dayKey = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
// a span of play, split at local midnights
function addToDays(days, from, to) {
  while (from < to) {
    const midnight = new Date(from);
    midnight.setHours(24, 0, 0, 0);
    const end = Math.min(to, midnight.getTime());
    days[dayKey(from)] = (days[dayKey(from)] || 0) + (end - from);
    from = end;
  }
}

// one writer at a time (polls and resets)
let playtimeLock = Promise.resolve();
function playtimeTx(fn) {
  const run = playtimeLock.then(fn, fn);
  playtimeLock = run.catch(() => {});
  return run;
}

function recordPlay(userId, p, game, now) {
  return playtimeTx(async () => {
    const { playtime = {} } = await ext.storage.local.get("playtime");
    const rec = playtime[userId] || { games: {}, days: {}, current: null };
    const cur = rec.current;
    if (p.status === "ingame" && p.universeId) {
      const uid = String(p.universeId);
      const g = rec.games[uid] ||= { name: "", placeId: 0, total: 0, sessions: 0, last: 0 };
      g.name = game?.name || g.name || "a game";
      g.placeId = game?.placeId || p.placeId || g.placeId;
      if (cur && cur.universeId === uid && now >= cur.last && now - cur.last <= PLAY_GAP) {
        g.total += now - cur.last;
        addToDays(rec.days, cur.last, now);
        cur.last = now;
        cur.name = g.name;
      } else {
        g.sessions += 1;
        rec.current = { universeId: uid, placeId: g.placeId, name: g.name, start: now, last: now };
      }
      g.last = now;
    } else if (cur) {
      rec.current = null;
    } else {
      return;
    }
    const days = Object.keys(rec.days).sort();
    for (const k of days.slice(0, Math.max(0, days.length - PLAY_DAYS))) delete rec.days[k];
    playtime[userId] = rec;
    await ext.storage.local.set({ playtime });
  });
}

function endSession(userId) {
  return playtimeTx(async () => {
    const { playtime = {} } = await ext.storage.local.get("playtime");
    if (!playtime[userId]?.current) return;
    playtime[userId].current = null;
    await ext.storage.local.set({ playtime });
  });
}

// ---------- admin dashboard (dad only, see S.ADMIN_ID) ----------
// Every 10 minutes while dad's browser is open: how many people are playing
// on Octane, Supa Games membership (who joined, who left), and keeping banned
// people out of the group. The dashboard (admin/admin.html) reads all of it.
const ADMIN_EVERY = 10 * 60 * 1000;
const ADMIN_HISTORY = 30 * 24 * 6; // 30 days of 10-minute points
const ADMIN_EVENTS = 300;
const KICK_RETRY_NOTE = 6 * 60 * 60 * 1000;

let adminLock = Promise.resolve();
function adminTx(fn) {
  const run = adminLock.then(fn, fn);
  adminLock = run.catch(() => {});
  return run;
}

async function adminState() {
  const got = await ext.storage.local.get({ adminHistory: null, adminMembers: null, adminEvents: [], adminBans: {} });
  return {
    history: { players: got.adminHistory?.players || [], members: got.adminHistory?.members || [] },
    members: got.adminMembers,
    events: got.adminEvents,
    bans: got.adminBans,
  };
}

function pollAdmin(force = false) {
  return adminTx(async () => {
    const { viewer = null, adminTimers = {} } = await ext.storage.local.get(["viewer", "adminTimers"]);
    if (!S.isAdmin(viewer)) return;
    const now = Date.now();
    if (!force && now - (adminTimers.at || 0) < ADMIN_EVERY) return;
    await ext.storage.local.set({ adminTimers: { at: now } });
    const st = await adminState();
    const patch = {};

    try {
      const games = await S.fetchTopGames(100);
      const total = games.reduce((n, g) => n + g.playing, 0);
      st.history.players.push([now, total]);
      const active = games.filter((g) => g.playing);
      patch.adminTop = { at: now, total, count: active.length, games: active.slice(0, 15) };
    } catch { /* try again next time */ }

    try {
      const members = await S.fetchGroupMembers(S.GROUP.id);
      const before = st.members;
      if (before?.ids) { // the first look is just the starting point
        const had = new Set(before.ids);
        const has = new Set(members.map((m) => m.id));
        for (const m of members) if (!had.has(m.id)) st.events.push({ t: now, type: "join", userId: m.id, name: m.displayName });
        for (const id of before.ids) if (!has.has(id)) st.events.push({ t: now, type: "leave", userId: id, name: before.names?.[id] || `#${id}` });
      }
      // banned people who joined again go straight back out
      const kicked = new Set();
      for (const m of members) {
        const ban = st.bans[m.id];
        if (!ban) continue;
        try {
          await S.kickFromGroup(S.GROUP.id, m.id);
          kicked.add(m.id);
          // only someone who was gone at the last look really rejoined; otherwise the first kick didn't work
          const rejoined = before?.ids && !before.ids.includes(m.id);
          st.events.push(rejoined
            ? { t: now, type: "rekick", userId: m.id, name: m.displayName }
            : { t: now, type: "ban", userId: m.id, name: m.displayName, detail: "removed from Supa Games on a retry" });
        } catch (err) {
          if (now - (ban.failAt || 0) > KICK_RETRY_NOTE) {
            ban.failAt = now;
            st.events.push({ t: now, type: "kick-failed", userId: m.id, name: m.displayName, detail: String(err.message || err) });
          }
        }
      }
      const stay = members.filter((m) => !kicked.has(m.id));
      patch.adminMembers = { at: now, ids: stay.map((m) => m.id), names: Object.fromEntries(stay.map((m) => [m.id, m.displayName])), count: stay.length };
      const last = st.history.members[st.history.members.length - 1];
      if (!last || last[1] !== stay.length || now - last[0] >= 60 * 60 * 1000) st.history.members.push([now, stay.length]);
    } catch { /* try again next time */ }

    patch.adminHistory = { players: st.history.players.slice(-ADMIN_HISTORY), members: st.history.members.slice(-ADMIN_HISTORY) };
    patch.adminEvents = st.events.slice(-ADMIN_EVENTS);
    patch.adminBans = st.bans;
    await ext.storage.local.set(patch);
  });
}

// Ban: out of Supa Games now, and kept out (pollAdmin removes them if they rejoin)
function adminBan(userId, name) {
  return adminTx(async () => {
    const { viewer = null } = await ext.storage.local.get("viewer");
    if (!S.isAdmin(viewer)) throw new Error("Only dad can ban people");
    userId = Number(userId);
    if (!userId || userId === S.ADMIN_ID) throw new Error("You can't ban yourself");
    const st = await adminState();
    const now = Date.now();
    let removed = false, error = "";
    try {
      await S.kickFromGroup(S.GROUP.id, userId);
      removed = true;
    } catch (err) {
      error = String(err.message || err);
    }
    // a failed first kick counts toward the 6-hour throttle on "kick failed" notes
    st.bans[userId] = { name: String(name || `#${userId}`).slice(0, 60), at: now, ...(removed ? {} : { failAt: now }) };
    st.events.push({ t: now, type: "ban", userId, name: st.bans[userId].name, detail: removed ? "removed from Supa Games" : `Octane didn't remove them (${error})` });
    const patch = { adminBans: st.bans, adminEvents: st.events.slice(-ADMIN_EVENTS) };
    if (removed && st.members?.ids) {
      const ids = st.members.ids.filter((id) => id !== userId);
      patch.adminMembers = { ...st.members, ids, count: ids.length };
    }
    await ext.storage.local.set(patch);
    // saved either way; kickError says why Octane didn't remove them
    return { removed, kickError: error };
  });
}

function adminUnban(userId) {
  return adminTx(async () => {
    const { viewer = null } = await ext.storage.local.get("viewer");
    if (!S.isAdmin(viewer)) throw new Error("Only dad can unban people");
    const st = await adminState();
    const ban = st.bans[userId];
    if (!ban) return { ok: true };
    delete st.bans[userId];
    st.events.push({ t: Date.now(), type: "unban", userId: Number(userId), name: ban.name });
    await ext.storage.local.set({ adminBans: st.bans, adminEvents: st.events.slice(-ADMIN_EVENTS) });
    return { ok: true };
  });
}

// ---------- admin widget on Octane pages (dad only) ----------
// content/admin-widget.js shows this snapshot bottom-left on octane.wtf. Any
// open Octane tab can ask for a fresh one; at most one fetch per WIDGET_MIN.
const WIDGET_MIN = 45 * 1000;
let widgetRun = null;
function refreshWidget(force = false) {
  widgetRun ??= buildWidget(force).finally(() => { widgetRun = null; });
  return widgetRun;
}

async function buildWidget(force) {
  const got = await ext.storage.local.get({ viewer: null, adminWidget: null, friendStatus: {}, adminHistory: null, adminEvents: [] });
  if (!S.isAdmin(got.viewer)) return null;
  const prev = got.adminWidget;
  const now = Date.now();
  if (!force && prev && now - prev.at < WIDGET_MIN) return prev;
  const snap = { at: now, total: prev?.total ?? null, games: prev?.games || [], supa: prev?.supa || null, trades: null };

  const [games, members, trades] = await Promise.allSettled([
    S.fetchTopGames(100), S.fetchGroupMembers(S.GROUP.id), S.fetchInboundTradeCount(),
  ]);
  if (games.status === "fulfilled") {
    const active = games.value.filter((g) => g.playing);
    snap.total = active.reduce((n, g) => n + g.playing, 0);
    const top = active.slice(0, 8);
    const icons = await S.fetchGameIcons(top.map((g) => g.universeId));
    snap.games = top.map((g) => ({ name: g.name, placeId: g.placeId, playing: g.playing, icon: icons[g.universeId] || "" }));
  }
  if (members.status === "fulfilled") {
    const presence = await S.fetchPresence(members.value.map((m) => m.id)).catch(() => null);
    if (presence) {
      const st = Object.values(presence).map((p) => p.status);
      snap.supa = { members: members.value.length, online: st.filter((s) => s !== "offline").length, ingame: st.filter((s) => s === "ingame").length };
    }
  }
  if (trades.status === "fulfilled") snap.trades = trades.value;

  const friends = Object.values(got.friendStatus).filter((f) => !f.error);
  snap.friends = { total: friends.length, online: friends.filter((f) => f.status !== "offline").length, ingame: friends.filter((f) => f.status === "ingame").length };

  // Octane right now against its busiest moment this week and today
  const players = got.adminHistory?.players || [];
  const midnight = new Date(now).setHours(0, 0, 0, 0);
  const nowCount = snap.total ?? 0;
  snap.octane = {
    now: nowCount,
    peak7: Math.max(nowCount, ...players.filter((p) => p[0] >= now - 7 * 86400000).map((p) => p[1])),
    peakToday: Math.max(nowCount, ...players.filter((p) => p[0] >= midnight).map((p) => p[1])),
  };
  snap.joins24 = got.adminEvents.filter((e) => e.type === "join" && now - e.t < 86400000).length;
  await ext.storage.local.set({ adminWidget: snap });
  return snap;
}

// ---------- item values (Octomons) ----------
let valuesLoading = null;
async function getValues(force = false) {
  const { itemValues = null, itemValuesAt = 0 } = await ext.storage.local.get(["itemValues", "itemValuesAt"]);
  if (!force && itemValues && Date.now() - itemValuesAt < V.TTL) {
    return { items: itemValues, updated: itemValuesAt };
  }
  valuesLoading ??= V.fetchValues()
    .then(async (items) => {
      const updated = Date.now();
      await ext.storage.local.set({ itemValues: items, itemValuesAt: updated, itemValuesError: null });
      return { items, updated };
    })
    .catch(async (err) => {
      const error = String(err.message || err);
      await ext.storage.local.set({ itemValuesError: error });
      return { items: itemValues || {}, updated: itemValuesAt, error };
    })
    .finally(() => { valuesLoading = null; });
  return valuesLoading;
}

// ---------- Supa Games perks ----------
// Membership of the Supa Games group unlocks themes, backgrounds, hide ads,
// price alerts and "can I afford it" alerts. Checked every 30 minutes, when
// the signed-in user changes, and when the popup asks.
async function runAccessCheck(force) {
  const { viewer = null, groupAccess = null } = await ext.storage.local.get(["viewer", "groupAccess"]);
  if (!viewer?.id) return groupAccess;
  const fresh = groupAccess?.userId === viewer.id && Date.now() - groupAccess.checkedAt < S.ACCESS_TTL;
  if (fresh && !force) return groupAccess;
  try {
    const next = { userId: viewer.id, member: await S.fetchGroupMember(viewer.id), checkedAt: Date.now() };
    // the account may have changed while we asked: then this answer is stale
    const { viewer: now = null } = await ext.storage.local.get("viewer");
    if (now?.id !== viewer.id) return runAccessCheck(true);
    await ext.storage.local.set({ groupAccess: next });
    return next;
  } catch {
    return groupAccess; // offline / rate limited: keep what we knew
  }
}
let accessCheck = null;
function checkAccess(force = false) {
  // a forced check (account switch, "I've joined") never reuses an answer
  // that was already on its way
  const run = () => runAccessCheck(force);
  const next = force && accessCheck ? accessCheck.then(run, run) : accessCheck || run();
  accessCheck = next.finally(() => { if (accessCheck === next) accessCheck = null; });
  return next;
}

// Timers and caches live in storage: Chrome's service worker and Firefox's
// event page are unloaded between alarms, which would reset anything kept
// in memory and make every check run every minute.
async function timers() {
  const { alertTimers = {} } = await ext.storage.local.get("alertTimers");
  return alertTimers;
}
async function setTimer(patch) {
  const t = await timers();
  await ext.storage.local.set({ alertTimers: { ...t, ...patch } });
}
const throttled403 = (err) => err?.status === 403 || err?.status === 429;
const pause = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- trade alerts (everyone) ----------
// tradeSeen: { [userId]: { maxId, ids } } — only trades newer than the newest
// one already seen alert, so trades sliding into the first page don't.
async function pollTrades(settings, viewer) {
  const { tradeSeen = {} } = await ext.storage.local.get("tradeSeen");
  if (!settings.enabled || !settings.notifyTrades || !viewer?.id) {
    // switched off: forget the baseline so switching back on starts fresh
    if (Object.keys(tradeSeen).length) await ext.storage.local.remove("tradeSeen");
    return;
  }
  let list;
  try {
    list = await S.fetchTrades("Inbound", 25);
  } catch {
    return; // signed out, or Octane is busy
  }
  const mine = tradeSeen[viewer.id];
  const maxOf = (ts) => ts.reduce((m, t) => Math.max(m, Number(t.id) || 0), 0);
  if (!mine) {
    // first look for this account: remember what's there, no alerts
    await ext.storage.local.set({ tradeSeen: { ...trimSeen(tradeSeen), [viewer.id]: { maxId: maxOf(list), ids: list.map((t) => t.id) } } });
    return;
  }
  const seen = new Set(mine.ids);
  const fresh = list.filter((t) => Number(t.id) > mine.maxId && !seen.has(t.id) && t.isActive !== false);
  if (!fresh.length) return;
  await ext.storage.local.set({ tradeSeen: { ...tradeSeen, [viewer.id]: {
    maxId: Math.max(mine.maxId, maxOf(fresh)),
    ids: [...new Set([...list.map((t) => t.id), ...mine.ids])].slice(0, 300),
  } } });
  const { items: values = {} } = await getValues();
  for (const t of fresh.slice(0, 5)) {
    const from = t.user?.displayName || t.user?.name || "someone";
    try {
      const d = await S.fetchTrade(t.id);
      const offers = d.offers || [];
      const myOffer = offers.find((o) => o.user?.id === viewer.id) || offers[0];
      const theirs = offers.find((o) => o !== myOffer) || offers[1];
      const side = (o) => V.offerTotals((o?.userAssets || []).map((a) => ({ assetId: a.assetId, rap: a.recentAveragePrice || 0 })), V.afterFee(o?.robux || 0), values);
      const give = side(myOffer), get = side(theirs);
      const v = V.verdict(give, get);
      const word = { win: "WIN", loss: "LOSS", fair: "FAIR" }[v.kind] || "New trade";
      const sign = v.diff > 0 ? "+" : v.diff < 0 ? "−" : "±";
      notify(`trade-${t.id}`, `${word}: trade from ${from}`,
        `You give ${V.fmt(give.value)} · you get ${V.fmt(get.value)} (${sign}${V.fmt(Math.abs(v.diff))} value)`);
    } catch {
      notify(`trade-${t.id}`, `New trade from ${from}`, "Open your trades to see it.");
    }
  }
  if (fresh.length > 5) notify("trade-more", `${fresh.length - 5} more new trades`, "Open your trades to see them all.");
}
// keep the per-account baselines to a few accounts
const trimSeen = (seen) => Object.fromEntries(Object.entries(seen).slice(-4));

// ---------- price-drop alerts (Supa Games) ----------
// The popup owns the list (priceAlerts); the background keeps what it saw
// per item in priceAlertState: { [assetId]: { lowest, checkedAt, notified } }
// and writes it right after each check, so a sleeping worker loses nothing.
async function pollPriceAlerts(settings, viewer) {
  if (!settings.enabled || !settings.perks || !settings.priceAlerts.length) return;
  const t = await timers();
  if (Date.now() - (t.priceAt || 0) < 2 * 60 * 1000 || Date.now() < (t.priceBackoffUntil || 0)) return;
  await setTimer({ priceAt: Date.now() });
  const { items: values = {} } = await getValues();
  for (const a of settings.priceAlerts.slice(0, 20)) {
    let best;
    try {
      best = await S.fetchLowestResale(a.assetId, viewer?.id);
    } catch (err) {
      if (throttled403(err)) { await setTimer({ priceBackoffUntil: Date.now() + 10 * 60 * 1000 }); return; } // Octane wants a break
      continue;
    } finally {
      await pause(400); // gentle on Octane, whatever happened
    }
    const { priceAlertState = {} } = await ext.storage.local.get("priceAlertState");
    const st = priceAlertState[a.assetId] || { notified: [] };
    st.lowest = best?.price ?? null;
    st.checkedAt = Date.now();
    let alert = null;
    if (best) {
      const value = values[a.assetId]?.value || 0;
      const underMax = a.max > 0 && best.price <= a.max;
      const underValue = a.belowValue && value > 0 && best.price < value;
      const key = `${best.userAssetId}:${best.price}`;
      if ((underMax || underValue) && !st.notified.includes(key)) {
        st.notified = [key, ...st.notified].slice(0, 10);
        alert = { why: underMax ? `your alert: ${V.fmt(a.max)} or less` : `below its value of ${V.fmt(value)}`, best };
      }
    }
    await ext.storage.local.set({ priceAlertState: { ...priceAlertState, [a.assetId]: st } });
    if (alert) notify(`item-${a.assetId}`, `${a.name} for ${V.fmt(alert.best.price)} Robux`, `Listed by ${alert.best.seller || "a reseller"} (${alert.why}).`);
  }
}

// ---------- "can I afford it" alerts (Supa Games) ----------
// affordState: { userId, states: { [outfitId]: "ok" | "short" | "none" }, robux }
// ownedCache:  { userId, ids, at } — the whole inventory, or nothing
async function ownedAssets(userId, refresh) {
  const { ownedCache = null } = await ext.storage.local.get("ownedCache");
  if (!refresh && ownedCache?.userId === userId && Date.now() - ownedCache.at < 15 * 60 * 1000) return new Set(ownedCache.ids);
  try {
    const ids = await S.fetchOwnedAssets(userId);
    await ext.storage.local.set({ ownedCache: { userId, ids: [...ids], at: Date.now() } });
    return ids;
  } catch {
    // incomplete (private inventory, or Octane busy): better no answer than a wrong one
    return ownedCache?.userId === userId ? new Set(ownedCache.ids) : null;
  }
}

async function pollAfford(settings, viewer) {
  if (!settings.enabled || !settings.perks || !settings.notifyAfford || !viewer?.id) return;
  const t = await timers();
  if (Date.now() - (t.affordAt || 0) < 5 * 60 * 1000) return;
  await setTimer({ affordAt: Date.now() });
  const { sandboxOutfits = [], affordState = null } = await ext.storage.local.get(["sandboxOutfits", "affordState"]);
  if (!sandboxOutfits.length) return;
  let balance;
  try {
    balance = await S.fetchBalance(viewer.id);
  } catch {
    return; // signed out
  }
  const sameUser = affordState?.userId === viewer.id;
  // spent Robux since last time: probably bought something, so look again
  const owned = await ownedAssets(viewer.id, sameUser && balance.robux < (affordState.robux ?? 0));
  if (!owned) return;
  const states = {};
  for (const o of sandboxOutfits) {
    let robux = 0, tix = 0, toBuy = 0;
    for (const it of o.items || []) {
      if (owned.has(it.id)) continue;
      if (it.price?.robux != null) { robux += it.price.robux; toBuy++; }
      else if (it.price?.tix != null) { tix += it.price.tix; toBuy++; }
    }
    const state = !toBuy ? "none" : robux <= balance.robux && tix <= balance.tickets ? "ok" : "short";
    states[o.id] = state;
    if (sameUser && state === "ok" && affordState.states?.[o.id] === "short") {
      const cost = [robux ? `${V.fmt(robux)} Robux` : "", tix ? `${V.fmt(tix)} Tix` : ""].filter(Boolean).join(" + ");
      notify(`outfit-${o.id}`, `You can afford "${o.name}" now`, `${cost} left to buy, and you have ${V.fmt(balance.robux)} Robux.`);
    }
  }
  // another account: start its baseline without alerts
  await ext.storage.local.set({ affordState: { userId: viewer.id, states, robux: balance.robux } });
}

async function pollAlerts() {
  const { viewer = null } = await ext.storage.local.get("viewer");
  await checkAccess();
  const settings = await S.load(); // after the check: perks may have just changed
  await pollTrades(settings, viewer);
  await pollPriceAlerts(settings, viewer);
  await pollAfford(settings, viewer);
}

let alerting = null;
function onTick() {
  getValues(); // refreshes when the cache is older than V.TTL
  // alerts after the friends poll, not at the same moment
  const friends = pollFriends().catch(() => {});
  alerting ??= friends.then(pollAlerts).catch(() => {}).then(() => pollAdmin()).catch(() => {}).finally(() => { alerting = null; });
}

// ---------- updates ----------
const IS_FIREFOX = typeof globalThis.browser?.runtime?.getBrowserInfo === "function";
const UPDATER_PAGE = "update/update.html";

// Firefox's own daily check found a signed update: apply it now instead of
// waiting for a browser restart.
ext.runtime.onUpdateAvailable?.addListener(() => ext.runtime.reload());

// How this copy can update itself:
//   firefox  signed install in Firefox/Zen: Kerosene downloads the signed .xpi
//            and hands it to Firefox's installer (Firefox asks the user twice)
//   store    installed from a web store: the browser fetches it
//   manual   loaded unpacked / temporarily: the user replaces the files
async function updateKind() {
  const self = await ext.management?.getSelf?.().catch(() => null);
  if (!self || self.installType === "development") return "manual";
  if (IS_FIREFOX) return "firefox";
  return typeof ext.runtime.requestUpdateCheck === "function" ? "store" : "manual";
}

// The signed .xpi of a release, downloaded and kept as an installable blob.
// It lives here rather than in the popup, which closes as soon as Firefox's
// installer window takes focus.
let staged = null; // { version, url, size, at }

async function sha256(buf) {
  const d = await crypto.subtle.digest("SHA-256", buf);
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function download(url, onProgress) {
  const res = await fetch(url, { cache: "no-store", credentials: "omit" });
  if (!res.ok) throw new Error(`download failed (HTTP ${res.status})`);
  const total = Number(res.headers.get("content-length")) || 0;
  if (!res.body?.getReader) return new Uint8Array(await res.arrayBuffer());
  const reader = res.body.getReader();
  const parts = [];
  let loaded = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    parts.push(value);
    loaded += value.byteLength;
    onProgress?.(loaded, total);
  }
  const out = new Uint8Array(loaded);
  let at = 0;
  for (const part of parts) { out.set(part, at); at += part.byteLength; }
  return out;
}

async function stageUpdate(info, onProgress) {
  if (staged && staged.version === info.version && Date.now() - staged.at < 30 * 60 * 1000) return staged;
  // the raw copy in the repo is the same signed file as the release asset, and
  // raw.githubusercontent.com allows extension fetches (release downloads don't)
  const base = info.firefox_xpi || `https://raw.githubusercontent.com/${S.REPO}/main/dist/kerosene-firefox.xpi`;
  let buf;
  for (let attempt = 0; attempt < 2; attempt++) {
    // a fresh query string per try gets past a stale CDN copy
    buf = await download(`${base}?v=${encodeURIComponent(info.version)}${attempt ? `&t=${Date.now()}` : ""}`, (l, t) => onProgress?.(l, t || info.firefox_size || 0));
    if (!info.firefox_sha256 || (await sha256(buf)) === info.firefox_sha256) break;
    if (attempt) throw new Error("the download didn't match the release; try again in a minute");
  }
  if (staged?.url) URL.revokeObjectURL(staged.url);
  staged = {
    version: info.version,
    url: URL.createObjectURL(new Blob([buf], { type: "application/x-xpinstall" })),
    size: buf.byteLength,
    at: Date.now(),
  };
  return staged;
}

// The popup opens the blob in a small window (a click is needed for Firefox
// to accept it). That window starts blank; once Firefox has picked up the
// file, it gets Kerosene's updater page instead.
let installer = null; // { tabId, windowId }
let expectInstaller = 0;
let pending = null; // what the new version needs to finish the job (also in storage)

// Firefox briefly refuses storage writes while its installer picks up the
// file, so keep trying for a few seconds.
async function persistPending() {
  for (let i = 0; i < 12; i++) {
    try {
      await (pending ? ext.storage.local.set({ pendingUpdate: pending }) : ext.storage.local.remove("pendingUpdate"));
      return;
    } catch {
      await new Promise((r) => setTimeout(r, 400));
    }
  }
}

ext.tabs.onCreated.addListener(async (tab) => {
  if (!staged || Date.now() - expectInstaller > 20000) return;
  pending = pending || (await ext.storage.local.get("pendingUpdate").catch(() => ({}))).pendingUpdate || null;
  const win = await ext.windows.get(tab.windowId).catch(() => null);
  if (win?.type !== "popup") return; // not ours (e.g. a new tab the user opened)
  expectInstaller = 0;
  installer = { tabId: tab.id, windowId: tab.windowId };
  if (pending) { pending.windowId = tab.windowId; persistPending(); }
  const q = new URLSearchParams({ from: ext.runtime.getManifest().version, to: staged.version });
  setTimeout(() => ext.tabs.update(tab.id, { url: ext.runtime.getURL(`${UPDATER_PAGE}?${q}`) }).catch(() => {}), 700);
});

// Closing the installer window without updating: put the page back
ext.windows.onRemoved.addListener(async (windowId) => {
  if (installer?.windowId !== windowId) return;
  installer = null;
  const was = pending;
  pending = null;
  persistPending();
  if (was?.tabId != null) ext.tabs.sendMessage(was.tabId, { type: "kerosene-update-screen", state: "hide" }).catch(() => {});
});

// The popup talks to the updater over a port so it can show download progress
ext.runtime.onConnect.addListener((port) => {
  if (port.name !== "kerosene-update") return;
  port.onMessage.addListener(async (msg) => {
    const send = (m) => { try { port.postMessage(m); } catch { /* popup closed */ } };
    if (msg?.type === "kind") return send({ type: "kind", kind: await updateKind() });
    if (msg?.type === "stage") {
      // remember who asked (before Firefox's installer gets busy with storage)
      const o = msg.origin || {};
      pending = {
        from: ext.runtime.getManifest().version, to: msg.info.version, at: Date.now(),
        // only Octane pages (where Kerosene's page script runs) answer this tab's messages
        tabId: o.tabId ?? null,
        originWindowId: o.windowId ?? null,
      };
      persistPending();
      try {
        const s = await stageUpdate(msg.info, (loaded, total) => send({ type: "progress", loaded, total }));
        expectInstaller = Date.now();
        send({ type: "staged", url: s.url, size: s.size });
      } catch (err) {
        send({ type: "error", error: String(err?.message || err) });
      }
    }
    if (msg?.type === "opening") {
      expectInstaller = Date.now();
      // the page you're on turns into Kerosene's loading screen meanwhile
      if (pending?.tabId != null) {
        ext.tabs.sendMessage(pending.tabId, { type: "kerosene-update-screen", state: "installing", from: pending.from, to: pending.to }).catch(() => {});
      }
    }
    if (msg?.type === "store") {
      const res = await ext.runtime.requestUpdateCheck();
      send({ type: "store", status: res?.status || res?.[0] || res }); // "update_available" -> onUpdateAvailable reloads us
    }
  });
});

// After an update: tidy up, refresh open Octane tabs so they run the new
// version, and (when the user started it) reopen the popup for the reveal.
async function afterUpdate(previousVersion) {
  const to = ext.runtime.getManifest().version;
  const { pendingUpdate } = await ext.storage.local.get("pendingUpdate").catch(() => ({}));
  const asked = Boolean(pendingUpdate && pendingUpdate.to === to && Date.now() - pendingUpdate.at < 30 * 60 * 1000);
  for (let i = 0; i < 10; i++) {
    try {
      await ext.storage.local.set({ justUpdated: { from: previousVersion, to, at: Date.now(), asked } });
      await ext.storage.local.remove("pendingUpdate");
      break;
    } catch {
      await new Promise((r) => setTimeout(r, 300));
    }
  }
  if (asked && pendingUpdate.windowId != null) await ext.windows.remove(pendingUpdate.windowId).catch(() => {});
  const tabs = await ext.tabs.query({ url: ["https://octane.wtf/*", "https://*.octane.wtf/*"] }).catch(() => []);
  for (const t of tabs) ext.tabs.reload(t.id).catch(() => {});
  if (asked) {
    if (pendingUpdate.originWindowId != null) await ext.windows.update(pendingUpdate.originWindowId, { focused: true }).catch(() => {});
    setTimeout(() => { ext.action?.openPopup?.()?.catch?.(() => {}); }, 400);
  }
}

ext.runtime.onInstalled.addListener((details) => {
  ensureAlarm();
  onTick();
  if (details?.reason === "update") afterUpdate(details.previousVersion);
});
ext.runtime.onStartup.addListener(() => { ensureAlarm(); onTick(); });
ext.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) onTick(); });

// a new signed-in user (or a settings change) should refresh straight away
ext.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.viewer || changes.syncFriends || changes.friends)) pollFriends();
  if (area === "local" && changes.viewer && changes.viewer.newValue?.id !== changes.viewer.oldValue?.id) checkAccess(true);
});

ext.notifications.onClicked.addListener((nid) => {
  const m = nid.match(/^kerosene-(game|user|trade|item|outfit)-([\w]+)-/);
  const urls = {
    game: (id) => `${S.SITE}/games/${id}`,
    user: (id) => `${S.SITE}/users/${id}/profile`,
    trade: () => `${S.SITE}/trades`,
    item: (id) => `${S.SITE}/catalog/${id}/item`,
    outfit: () => `${S.SITE}/my/avatar`,
  };
  if (m) ext.tabs.create({ url: urls[m[1]](m[2]) });
  ext.notifications.clear(nid);
});

ext.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === "refresh-friends") {
    pollFriends().then(reply, () => reply(null));
    return true;
  }
  if (msg?.type === "playtime-reset" && msg.userId) {
    playtimeTx(async () => {
      const { playtime = {} } = await ext.storage.local.get("playtime");
      delete playtime[msg.userId];
      await ext.storage.local.set({ playtime });
    }).then(() => reply(true), () => reply(false));
    return true;
  }
  if (msg?.type === "admin-widget") {
    refreshWidget(Boolean(msg.force)).then(reply, () => reply(null));
    return true;
  }
  if (msg?.type === "open-admin") {
    ext.tabs.create({ url: ext.runtime.getURL("admin/admin.html") }).then(() => reply(true), () => reply(false));
    return true;
  }
  if (msg?.type === "admin-refresh") {
    pollAdmin(true).then(() => reply({ ok: true }), (err) => reply({ error: String(err?.message || err) }));
    return true;
  }
  if (msg?.type === "admin-ban") {
    adminBan(msg.userId, msg.name).then(reply, (err) => reply({ error: String(err?.message || err) }));
    return true;
  }
  if (msg?.type === "admin-unban") {
    adminUnban(msg.userId).then(reply, (err) => reply({ error: String(err?.message || err) }));
    return true;
  }
  if (msg?.type === "check-access") {
    checkAccess(Boolean(msg.force)).then(reply, () => reply(null));
    return true;
  }
  if (msg?.type === "update-staged") {
    reply(staged ? { url: staged.url, version: staged.version } : null);
    return false;
  }
  if (msg?.type === "update-restage") {
    stageUpdate(msg.info).then((s) => reply({ url: s.url, version: s.version }), (err) => reply({ error: String(err?.message || err) }));
    return true;
  }
  if (msg?.type === "get-values") {
    getValues(Boolean(msg.force)).then(reply, (err) => reply({ items: {}, updated: 0, error: String(err) }));
    return true;
  }
  // Content scripts can't read cross-origin stylesheets; with host access the
  // service worker can fetch their text so themes can recolour them too.
  if (msg?.type === "fetch-css" && /^https?:\/\//.test(msg.url)) {
    fetch(msg.url, { credentials: "omit" })
      .then((r) => (r.ok ? r.text() : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((text) => reply({ text }), (err) => reply({ error: String(err.message || err) }));
    return true;
  }
});
